package me.deadlight.ezchestshop.enums;

public enum Database {
    SQLITE,
    MYSQL,
}
