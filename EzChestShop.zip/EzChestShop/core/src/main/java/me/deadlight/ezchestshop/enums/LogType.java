package me.deadlight.ezchestshop.enums;

public enum LogType {
    TRANSACTION,
    ACTION
}
