![first img](https://user-images.githubusercontent.com/20891968/222954783-8d4dcfa0-6afd-4e1b-816b-10e0de407c58.png)

<a href="https://discord.gg/rSfsqgCqBZ">![Discord](https://img.shields.io/discord/902975048514678854?label=discord&logo=discord)</a>
<a href="https://www.spigotmc.org/resources/90411/">![Download Size](https://img.shields.io/spiget/download-size/90411)</a>
<a href="https://www.spigotmc.org/resources/90411/">![Total Spigot Downloads](https://img.shields.io/spiget/downloads/90411)</a>
<a href="https://www.spigotmc.org/resources/90411/">![Spigot Rating](https://img.shields.io/spiget/rating/90411)</a>
<a href="https://www.spigotmc.org/resources/90411/">![Current Version](https://img.shields.io/spiget/version/90411?label=version)</a>
<a href="https://bstats.org/plugin/bukkit/Ez%20Chest%20Shop/10756">![Servers](https://img.shields.io/bstats/servers/10756)</a>

Welcome to EzChestShop! A Chest Shop plugin that's simple to use, filled with features and increadibly customizeable! Head over to [spigotmc.org](https://www.spigotmc.org/resources/90411/) to try the compiled version of EzChestShop for yourself!

### Configuration
If you want to customize EzChestShop, check out our Wiki, we have a section about the [config.yml](https://github.com/ItzAmirreza/EzChestShop/wiki/Configuration)!

### Found a bug, miss a feature?
Create an [Issue](https://github.com/ItzAmirreza/EzChestShop/issues) or let us know on [Discord](https://discord.gg/rSfsqgCqBZ)! We're always happy to help you out if you experience any troubles, though maybe you'll already find your answer in our #faq on Discord!

### Contributing:
Want a feature implemented quickly? The fastest way is by creating the feature yourself via a [Pull Request](https://github.com/ItzAmirreza/EzChestShop/pulls)! See the Wiki for more Infos on how to [contribute](https://github.com/ItzAmirreza/EzChestShop/wiki/Contributing)!


Ignore this part:

![2023-03-04_20 35 02](https://user-images.githubusercontent.com/20891968/222955476-71ee5ecc-f3da-4cdc-b45c-e00d1f75075f.png)
![2021-09-03_01 23 00](https://user-images.githubusercontent.com/20891968/222955507-ff555513-6ac9-4467-bb81-1208f606e3e9.png)
![2021-09-03_12 35 36](https://user-images.githubusercontent.com/20891968/222955533-8ee09b99-408b-46ce-84be-4560960578af.png)
![intro](https://user-images.githubusercontent.com/20891968/222955564-8033589b-55bf-4691-a807-5545d64a13b1.png)
![INFINITE FEATURES](https://user-images.githubusercontent.com/20891968/222955639-416168a6-4068-41ef-8681-7ad514515701.png)
![2021-09-03_00 25 24](https://user-images.githubusercontent.com/20891968/222955746-57e32bef-4db1-46a1-b516-fd348c6e5771.png)
![2021-09-03_00 25 27](https://user-images.githubusercontent.com/20891968/222955777-86e24de4-826e-481e-af3e-c2c06188409e.png)
![2021-09-03_00 25 32](https://user-images.githubusercontent.com/20891968/222955806-d42d6d05-39bd-4566-bbf7-a62e2d26906c.png)
![2023-03-04_20 35 10](https://user-images.githubusercontent.com/20891968/222955828-07add018-aa62-433d-9880-4208655a8dcf.png)

![Content_creators](https://user-images.githubusercontent.com/20891968/222956041-217ea30b-5f9a-4bb8-a304-ed5962bc44d6.png)
![installations](https://user-images.githubusercontent.com/20891968/222956199-6f278a98-13d0-40ec-8389-4199df2a1705.png)


![commands](https://user-images.githubusercontent.com/20891968/222956230-d71ce7ea-4295-4440-bc44-e13da3d543d8.png)
![support](https://user-images.githubusercontent.com/20891968/222956443-00dc0c63-51dc-4e5d-86a3-b5e5dc70587f.png)
![image](https://user-images.githubusercontent.com/20891968/235449301-7a12b967-a837-4e64-8e0b-c871a53e854e.png)
![image](https://user-images.githubusercontent.com/20891968/235449309-ead31b66-7a06-4c1a-b79d-1c5cf2c41ed8.png)





